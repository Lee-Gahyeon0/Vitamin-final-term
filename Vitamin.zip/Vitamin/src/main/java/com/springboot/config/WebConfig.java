package com.springboot.config;

import com.springboot.interceptor.AdminCheckInterceptor;
import com.springboot.interceptor.LoginCheckInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addInterceptors(InterceptorRegistry registry) {

        // 1) 로그인 체크 인터셉터
        registry.addInterceptor(new LoginCheckInterceptor())
                .addPathPatterns("/**")   // 기본적으로 전부 적용
                .excludePathPatterns(
                        "/",                // 홈
                        "/members/login",   // 로그인 페이지
                        "/members/register",// 회원가입 페이지
                        "/css/**", "/js/**", "/images/**" // 정적 리소스
                );

        // 2) 관리자 권한 체크 인터셉터
        registry.addInterceptor(new AdminCheckInterceptor())
                .addPathPatterns("/admin/**");   // /admin/으로 시작하는 URL만
    }
}
