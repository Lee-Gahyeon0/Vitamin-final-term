package com.springboot.domain;

public enum InteractionSeverity {
    LOW,
    MID,
    HIGH
}