package interceptor.copy;

import com.springboot.domain.Member;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.web.servlet.HandlerInterceptor;

public class LoginCheckInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request,
                             HttpServletResponse response,
                             Object handler) throws Exception {

        // 기존 세션 있으면 가져오고, 없으면 null
        HttpSession session = request.getSession(false);

        // 세션 없거나, 로그인 정보 없으면 → 로그인 페이지로
        if (session == null || session.getAttribute("loginMember") == null) {
            // 지금 요청 URL을 나중에 돌아오게 하려면 쿼리스트링으로 달 수도 있음 (선택)
            response.sendRedirect("/members/login");
            return false;   // 컨트롤러로 안 가고 여기서 끝
        }

        // 로그인 되어 있으면 통과
        return true;
    }
}

